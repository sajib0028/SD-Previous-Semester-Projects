package multihreading;

import java.util.Scanner;

/**
 * Description: This program has been developed by using multi-threading in Java
 * @author Sajib Biswas
 * @version 1.00 Implementation of all CGOL rules
 *
 */
public class CGOL{
	public static void main(String args[]) {
		int arr[][]=new int[6][6];    // Declaring an array and Initiate the row and column size as '6'
		System.out.println("Entry must be in 0 and 1, 0 for the dead cell and 1 for the alive cell");
		int i,j = 0;
		@SuppressWarnings("resource")
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter values: ");
		// Taking the input from keyboard for initial state
		for(i=0;i<6;i++) {	
		   for(j=0;j<6;j++) {
			  arr[i][j]=sc.nextInt();	
		      }
		}
		//Print the entered values from keyboard
		System.out.println("Entered values are: ");
		for(i=0;i<6;i++) {
			for(j=0;j<6;j++) {
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
	}
//Method calling for wrong input
		check(arr);
	// Create an object of CGOL1 class 
		CGOL1 a1=new CGOL1(arr);
	//Executing the thread
		a1.start();
	// Set the priority level
		a1.setPriority(8);
		
		
	}
	/** Method to check the wrong input
	 * If the user enter values except '0' or '1', an error message will appear.
	*/
public static int check(int[][] a) {
  int i,j;
  for(i=0;i<6;i++){
      for(j=0;j<6;j++){
	      if(a[i][j]!=1 && a[i][j]!=0){
		System.out.println("Error! Can't Implement the rules of CGOL. Because there are wrong inputs.");					
		System.exit(1);
					}
				}	
          }
return 1;

	}
}

class CGOL1 extends Thread{
	
	private int arr[][];
	private int array[][]=new int[6][6];
	//Create a constructor
 public CGOL1( int[][] arr) {
this.arr=arr;
 }
 //create run method and implement the rules.
public void run() {
	//Calculating the time elapsed so far.
	long startTime = System.nanoTime();
@SuppressWarnings("resource")
Scanner scan=new Scanner(System.in);
int i,j;
for(i=0;i<6;i++){
	for(j=0;j<6;j++){
        array[i][j]=0;
		}
	}

System.out.print("Enter how many generation you want: ");

int states,f;
states=scan.nextInt();  // getting the number of expected state
for(f=1;f<=states;f++) {
	// Loop through every cell of the every row and column
	for(i=1;i<5;i++) {
		for(j=1;j<5;j++) {
			int l,k,alive=0;
			// Finding how many cells are alive
			for ( l = -1; l <= 1; l++) 
				for (k = -1; k <= 1; k++) 

					alive=alive+arr[i+l][j+k]; 
			// The cell needs to be subtracted from 
			// its neighbors as it was counted before 
			alive =alive- arr[i][j]; 

			// Implementing the Rules of Life 

			// Cell is lonely and dies 
			if ((arr[i][j] == 1) && (alive < 2)) 
				array[i][j] = 0; 

			// Cell dies due to over population 
			else if ((arr[i][j] == 1) && (alive > 3)) 
				array[i][j] = 0; 

			// A new cell is born 
			else if ((arr[i][j] == 0) && (alive == 3)) 
				array[i][j] = 1; 

			// Remains the same 
			else
				array[i][j] = arr[i][j]; 
		}
	}

//Printing the next life
System.out.println( f + " life is: ");

int l,k;
for(k=0;k<6;k++) {
	for(l=0;l<6;l++) {
		System.out.print(array[k][l]+ " ");
	}
	System.out.println();
}
//Assigning the next life to the main array to print further generation
for(k=0;k<6;k++){
	for(l=0;l<6;l++){
		arr[k][l]=array[k][l];
	}
}
//Calculating the time to execution of each generation of CGOL
long time = System.nanoTime() - startTime;
System.out.println("Time taken to generate the"+" "+ f  + " generation is: " + time + " ns");
System.out.println();
        }
    }	
}

