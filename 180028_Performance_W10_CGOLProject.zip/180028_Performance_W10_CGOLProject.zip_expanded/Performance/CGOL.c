#include <stdio.h>
#include <stdlib.h>
int main() {
int i,j;
int array[10][10];            //It will take 10 rows and 10 column initially
printf("The Game take '0'as dead and '1' as live\n");//'0' for dead and '1' for live
fflush(stdout);
printf("Enter initial state as a form of 0 and 1 only: ");
fflush(stdout);
		for(i=0;i<10;i++){
        printf("Enter the %d row",i+1);
        fflush(stdout);
			for(j=0;j<10;j++){
				scanf("%d",&array[i][j]);
			}

		}
	for(i=0;i<10;i++){
		for(j=0;j<10;j++){
			printf("%d",array[i][j]);
		}
		printf("\n");
	}
//Method
const int x=10,y=10;  // Taking number of rows and column
	void CGOL(int x,int y,int array[x][y]);
	CGOL(x,y, array);
	return 0;
}


void CGOL(int a, int b, int ar[a][b]){ //CGOL implementation

	int array[10][10];
int d,e;
	for(d=0;d<10;d++){
		for(e=0;e<10;e++){
array[d][e]=0;

		}
	}
printf("Enter expected generations: \n");
fflush(stdout);
int states;
scanf("%d",&states);
int f;
for(f=1;f<=states;f++){
	int i,j;
	int alive=0;
		for(i=0;i<10;i++){
			for(j=0;j<10;j++){
           alive=0;
/**
 * Check and count the number of element in neighbor
 * As one has 8 neighbor thats why it will check 8 times to check and count his neighbor element
 */
	if(ar[i-1][j-1]==1){		//It check's the left neighbor
		alive++;
	}
	if(ar[i][j+1]==1){		//It check's the right neighbor
				alive++;
			}
	if(ar[i-1][j]==1){		//It check's the up neighbor
			alive++;
		}
	if(ar[i-1][j+1]==1){		//It check's the checks the up right neighbor
			alive++;
		}

	if(ar[i][j-1]==1){		//It check's the up left neighbor
			alive++;
		}
	if(ar[i+1][j-1]==1){		//It check's the bottom left neighbor
			alive++;
		}

	if(ar[i+1][j]==1){		//It check's the bottom neighbor
			alive++;
		}

	if(ar[i+1][j+1]==1){		//It check's the bottom right neighbor
			alive++;
		}

/**
 * Implementation of CGOl rules
 */

	if(alive<2){
		array[i][j]=0;
	}
	else if(alive==2){
		if(ar[i][j]==1){
			array[i][j]=1;
		}
		else{
		array[i][j]=0;
		}
	}
	else if (alive==3){
		array[i][j]=1;
	}
else if(alive>3){
		array[i][j]=0;

		}
	}

}
	printf("%d stage \n",f);  //Print new array after implementing all the rules
	fflush(stdout);
	int k,l;
			for(k=0;k<10;k++){
					for(l=0;l<10;l++){
						printf("%d",array[k][l]);
					}
					printf("\n");
				}
		for(k=0;k<10;k++){                    //values of new array
				for(l=0;l<10;l++){
					ar[k][l]=array[k][l];
					}
				}
	}

}

