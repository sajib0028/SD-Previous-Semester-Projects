package dictionary;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import addresses.TestMainline;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.shape.Rectangle;

/*******
 * <p>
 * Title: UserInterface Class.
 * </p>
 * 
 * <p>
 * Description: A JavaFX demonstration application: This controller class
 * describes the user interface for the Exercise04 demonstration application
 * </p>
 * 
 * <p>
 * Copyright: Lynn Robert Carter © 2018-08-04
 * </p>
 * 
 * @author Lynn Robert Carter
 * @author Sajib Biswas
 * 
 * @version 1.00 2018-07-19 Baseline.
 * @version 3.00 2019-09-08 Implementation of javaFx TabPane and Tab classes
 * 
 */
public class UserInterface {

	/**********************************************************************************************
	 * 
	 * Class Attributes
	 * 
	 **********************************************************************************************/

	
	private double controlPanelHeight = TestMainline.WINDOW_HEIGHT - 110;
	private int marginWidth = 20;
	private String searchString; 
	private int numberEntriesFormatted;

	
	private Label label_FileName = new Label("Enter the file's name of Dictionary here:");  
	private Label label_Def = new Label(""); 
	private Label label_Search = new Label("Enter search text or word:"); 
	private TextField text_FileName = new TextField();
	private TextField text_Search = new TextField(); 
	private Button button_Load = new Button("Load the dictionary"); 
	private Button button_Search = new Button("Search"); 
	private Label label_EntriesFound = new Label("");         
	private String str_FileName;              
	private Scanner scanner_Input = null;     
	private Label message_FileFound = new Label("");      
	private Label message_FileNotFound = new Label("");  
	private String errorMessage_FileContents = "";             
	private Label message_ErrorDetails = new Label("");        
	private Pane window;  
	private Rectangle rect_outer = new Rectangle(0, 75, TestMainline.WINDOW_WIDTH, controlPanelHeight - 5);
	private Rectangle rect_middle = new Rectangle(5, 5, TestMainline.WINDOW_WIDTH - 10, controlPanelHeight - 100);
	private Rectangle rect_inner = new Rectangle(6, 6, TestMainline.WINDOW_WIDTH - 12, controlPanelHeight - 100);
	private TextArea blk_Text = new TextArea("");
	private int numberOfLinesInTheInputFile = 0; 
	private boolean firstRead = true;
	private Dictionary theDictionary = null;

	/**********************************************************************************************
	 * 
	 * Constructors
	 * 
	 **********************************************************************************************/

	/**********
	 * This constructor established the user interface with all of the graphical
	 * widgets that are use to make the user interface work.
	 * 
	 * @param theRoot This parameter is the Pane that JavaFX expects the application
	 *                to use when it sets up the GUI elements.
	 */
	public UserInterface(Pane theRoot) {
		window = theRoot; 
		rect_outer.setFill(Color.LIGHTGRAY);
		rect_middle.setFill(Color.BLACK);
		rect_inner.setFill(Color.WHITE);

	
		
		setupTextAreaUI(blk_Text, "Monaco", 14, 6, 6, TestMainline.WINDOW_WIDTH - 12, controlPanelHeight - 100, false);

		setupLabelUI(label_FileName, "Arial", 18, TestMainline.WINDOW_WIDTH - 20, Pos.BASELINE_LEFT, marginWidth,
				controlPanelHeight - 80);

		setupTextUI(text_FileName, "Arial", 18, TestMainline.WINDOW_WIDTH / 2, Pos.BASELINE_LEFT, marginWidth,
				controlPanelHeight - 56, true);

		text_FileName.textProperty().addListener((observable, oldValue, newValue) -> {
			checkFileName();
		});

		setupButtonUI(button_Load, "Arial", 18, 100, Pos.BASELINE_LEFT, 650, controlPanelHeight - 56);

		button_Load.setOnAction((event) -> {
			loadTheData();
		});

		button_Load.setDisable(true); 

		setupLabelUI(label_Def, "Arial", 18, TestMainline.WINDOW_WIDTH - 20, Pos.BASELINE_LEFT, marginWidth,
				controlPanelHeight - 80);

		label_Def.setVisible(false);

		setupLabelUI(label_Search, "Arial", 18, TestMainline.WINDOW_WIDTH - 20, Pos.BASELINE_LEFT, marginWidth,
				controlPanelHeight - 56);

		setupLabelUI(label_EntriesFound, "Arial", 18, TestMainline.WINDOW_WIDTH - 20, Pos.BASELINE_LEFT, marginWidth,
				controlPanelHeight);

		setupTextUI(text_Search, "Arial", 18, TestMainline.WINDOW_WIDTH / 2, Pos.BASELINE_LEFT, marginWidth,
				controlPanelHeight - 32, true);

		text_Search.textProperty().addListener((observable, oldValue, newValue) -> {
			checkString();
		});

		setupButtonUI(button_Search, "Arial", 18, 100, Pos.BASELINE_LEFT, 700, controlPanelHeight - 32);

		button_Search.setOnAction((event) -> {
			Searchforword();
		});
    
		setupLabelUI(message_FileFound, "Arial", 18, 150, Pos.BASELINE_LEFT, 650, controlPanelHeight - 80);
		message_FileFound.setStyle("-fx-text-fill: green; -fx-font-size: 18;");

		setupLabelUI(message_FileNotFound, "Arial", 18, 150, Pos.BASELINE_LEFT, 650, controlPanelHeight - 80);
		message_FileNotFound.setStyle("-fx-text-fill: red; -fx-font-size: 18;");

		setupLabelUI(message_ErrorDetails, "Arial", 16, TestMainline.WINDOW_WIDTH, Pos.BASELINE_LEFT, 20,
				controlPanelHeight);

		message_ErrorDetails.setStyle("-fx-text-fill: red; -fx-font-size: 14;");
		button_Search.setVisible(false); 
		text_Search.setVisible(false); 
		label_EntriesFound.setVisible(false); 
		label_Search.setVisible(false); 

		
		theRoot.getChildren().addAll(rect_outer, rect_middle, rect_inner, label_FileName, text_FileName, button_Load,
				message_FileFound, message_FileNotFound, message_ErrorDetails, blk_Text, text_Search, button_Search,
				label_Def, label_Search, label_EntriesFound);
	}

	/**********************************************************************************************
	 * 
	 * Helper methods - Used to set up the JavaFX widgets and simplify the code
	 * above
	 * 
	 **********************************************************************************************/

	/**********
	 * Private local method to initialize the standard fields for a label
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a text field
	 */
	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e) {
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}

	/**********
	 * Private local method to initialize the standard fields for a text field
	 */
	private void setupTextAreaUI(TextArea t, String ff, double f, double x, double y, double w, double h, boolean e) {
		t.setFont(Font.font(ff, f));
		t.setPrefWidth(w);
		t.setPrefHeight(h);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
		t.setWrapText(true);
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

	/**********************************************************************************************
	 * 
	 * Action methods - Used cause things to happen with the set up or during the
	 * simulation
	 * 
	 **********************************************************************************************/

	/**********
	 * This routine checks, after each character is typed, to see if the game of
	 * life file is there and if so, sets up a scanner to it and enables a button to
	 * read it and verify that it is ready to be used by the application.
	 * 
	 * If a file of that name is found, it checks to see if the contents conforms to
	 * the specification. If it does, the Load button is enabled and a green message
	 * is displayed If it does not, the Load button is disabled and a red error
	 * message is displayed If a file is not found, a warning message is displayed
	 * and the button is disabled. If the input is empty, all the related messages
	 * are removed and the Load button is disabled.
	 */
	void checkFileName() {
		str_FileName = text_FileName.getText(); 
		if (str_FileName.length() <= 0) { 
			message_FileFound.setText(""); 
			message_FileNotFound.setText("");
			scanner_Input = null;
		} 
		else 
			try { 
				scanner_Input = new Scanner(new File(str_FileName));
				if (fileContentsAreValid()) {
					message_FileFound.setText("File found and contents are valid!");
					message_ErrorDetails.setText("");
					message_FileNotFound.setText("");
					button_Load.setDisable(false); 
				}
				else { 
					message_FileFound.setText("");
					message_FileNotFound.setText("File found, but the contents are not valid!");
					message_ErrorDetails.setText(errorMessage_FileContents);
					button_Load.setDisable(true); // Set Load button to disable
				}

			} catch (FileNotFoundException e) { // If there an exception occur in file name
				message_FileFound.setText(""); // that the button to run the analysis is
				message_FileNotFound.setText("File not found!"); // not enabled.
				message_ErrorDetails.setText("");
				scanner_Input = null;
				button_Load.setDisable(true); // Set Load buttons to disable
			}
	}

	/**********
	 * This method reads in the contents of the data file and discards it as quickly
	 * as it reads it in order to verify that the data meets the input data
	 * specifications and helps reduce the change that invalid input data can lead
	 * to some kind of hacking.
	 * 
	 * @return true - when the input file *is* valid when the input file data is
	 *         *not* valid - The method also sets a string with details about what
	 *         is wrong with the input data so the user can fix it
	 */
	private boolean fileContentsAreValid() {

	
		numberOfLinesInTheInputFile = 0;
		String firstLine = "";
		if (scanner_Input.hasNextLine()) {
			firstLine = scanner_Input.nextLine().trim(); 
			if (firstLine.equalsIgnoreCase("Demonstration")) 
				numberOfLinesInTheInputFile = 1; 
			else { 
				System.out.println("\n***Error*** The first line does not consist of the word \"Demonstration\""
						+ " as required by the specification.");
				return false; 
			}
		} else {
			
			System.out.println("\n***Error*** The file appears to be empty.");
			return false;
		}

		while (scanner_Input.hasNextLine()) {
			numberOfLinesInTheInputFile++; // Count the number of input lines
			String inputLine = scanner_Input.nextLine();
			if (inputLine.length() > 250) {	
				System.out.println("\n***Error*** Line " + numberOfLinesInTheInputFile + " contains "
						+ inputLine.length() + " characters, which is greater than the limit of 250.");
				return false;
			}
		}

		errorMessage_FileContents = ""; 
		return true; 
	}

	/**********
	 * This private method reads the data from the data file and places it into a
	 * data structure for later processing, should the user decide to do that.
	 * (Recall that the input has already been scanned by the function
	 * fileContentsAreValid(), so redundant checks are not needed.)
	 * 
	 * If during this process, the user should press the Stop button, the reading
	 * will stop.
	 * 
	 * @param in The parameter is a Scanner object that is set up to read the input
	 *           file
	 */
	private void readTheData(Scanner in) {
		
		if (firstRead)
			theDictionary = new Dictionary();
		theDictionary.defineDictionary(in);
		label_Def.setText("The number of definitions:" + theDictionary.getNumEntries());
		Platform.runLater(() -> {
			if (firstRead) { 
				window.getChildren().remove(button_Load); 
			}
		});
	}

	/**********
	 * This private method is called when the Load button is pressed. It tries to
	 * load the data into theData data structure for future analysis, if the user
	 * wishes to do that. The method also manages the change of state of the various
	 * buttons associated with the user interface during the process.
	 * 
	 * To properly enable the concurrent activities with the user interface, this
	 * method uses a different thread to actually read in the data, leaving this
	 * thread available to deal with any user commands and to update the user
	 * interface as the reading takes place (e.g. this allows the progress bar to be
	 * updated *while* the reading is taking place.)
	 */
	private void loadTheData() {

		button_Load.setDisable(true); 
		button_Search.setDisable(true);
		button_Search.setVisible(true); 
		text_Search.setVisible(true);   
		text_FileName.setVisible(false);
		label_FileName.setVisible(false); 
		label_Def.setVisible(true); 
		label_Search.setVisible(true); 
	
		try {
			final Scanner dataReader = new Scanner(new File(str_FileName)); // read the data from file
			readTheData(dataReader);
		}
		catch (FileNotFoundException e) {
			
			System.out.println("***Error*** A truly unexpected error occured.");
		}
		text_FileName.setText("");
	};

	/**
	 * Given the user has changed the search text string or has changed the file
	 * name, reset the search message and set up the search button if there is a
	 * dictionary, there are dictionary entries in the dictionary, the system is not
	 * reading in a new dictionary, and there is at least one character in the
	 * search text field.
	 * 
	 */
	private void checkString() {
		if (theDictionary == null || theDictionary.getNumEntries() <= 0) {
			button_Search.setDisable(true);
			return;
		}
		searchString = text_Search.getText().trim();
		if (searchString.length() > 0)
			button_Search.setDisable(false);
		else
			button_Search.setDisable(true);
		label_EntriesFound.setText("");
	}

	/**
	 * Search for all words that contain the specified search string. Concatenate
	 * the words with their definition to the display.
	 * 
	 */
	private void Searchforword() {
	
		if (theDictionary != null && searchString.length() > 0) {


			theDictionary.setSearchString(searchString);

		
			int numFound = 0;                                    
			DictEntry[] found = new DictEntry[theDictionary.getNumEntries()];

			
			DictEntry de = theDictionary.findNextEntry();                
			while (de != null) {                                        
				found[numFound++] = de;
				de = theDictionary.findNextEntry();
			}
			label_EntriesFound.setVisible(true);                        

			label_EntriesFound.setText(new Integer(numFound).toString()+" items found in search");
			
			String result = "";
			for (numberEntriesFormatted = 0; numberEntriesFormatted < numFound; numberEntriesFormatted++) {
				result = result + found[numberEntriesFormatted].toString(); 
			}
			blk_Text.setText(result);        

			button_Search.setDisable(true);          
		}
	}
}