package addresses;

import dictionary.UserInterface;
import javafx.application.Application;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.Screen;
import javafx.stage.Stage;

/*******
 * <p>
 * Title: Exercise10AddressesTestMainline Class
 * </p>
 * 
 * <p>
 * Description: A JavaFX demonstration application: This controller class sets
 * up the key attributes and classes for the Exercise10 demonstration
 * application
 * </p>
 * 
 * <p>
 * Copyright: Lynn Robert Carter © 2018-08-26
 * </p>
 * 
 * @author Lynn Robert Carter
 * @author Sajib Biswas
 * 
 * @version 1.00 2018-07-19 Baseline
 * @version 3.00 2019-09-08 Implementation of javaFx TabPane and Tab classes
 * 
 */
public class TestMainline extends Application {

	public UserInterfaceAdd theGUI;
	public UserInterfaceAdd appendAddress;
	public UserInterface theGUI0;

	public static double WINDOW_HEIGHT;
	public static double WINDOW_WIDTH;

	/**********
	 * This method is the root of the application and from it, the foundations of
	 * the application establish, the GUI is linked to the methods of various
	 * classes and the setup is performed.
	 * 
	 * This method queries the environment to determine the size of the window that
	 * is at the heart of the Graphical User Interface (GUI). The method is called
	 * with a single parameter that specified the Stage object that JavaFX
	 * applications use.
	 * 
	 * The method starts by creating a Pane object, calls the GUI to instantiate the
	 * GUI widgets using that Pane, creates a Scene using that Pane as a window of a
	 * size that will fit the specifics of the system running the application. Once
	 * the Scene is set, it is shown to the user, and at that moment the application
	 * changes from a programmed sequence of actions set by the programmer into a
	 * set of actions determined by the user by means of the various GUI elements
	 * the user selects and uses.
	 * 
	 * @param theStage is a Stage object that is passed in to the methods and is
	 *                 used to set up the the controlling object for the
	 *                 application's user interface
	 */
	public void start(Stage theStage) throws Exception {

		// Demonstrate that Intern Address holds the data and prints it
		// properly
		InternAddress internadd = new InternAddress("Sajib Biswas",
				"Hostel-10-251 (MMEC Campus)", "Ambala", "Haryana", "133-207", "INDIA");

		// Demonstrate that the Client Address holds the data and prints it properly
		ClientAddress clientadd = new ClientAddress("ACE Enterprise LTD.",
				"Ambala", "Mullana ", "133-207", "(Harayana)", "India");
		
		// Determine the actual visual bounds for this display
		Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();

		// Set the Stage boundaries to the visual bounds so the window does not totally
		// fill the screen
		WINDOW_WIDTH = primaryScreenBounds.getWidth() - primaryScreenBounds.getMinX() - 100;
		if (WINDOW_WIDTH > 1000)
			WINDOW_WIDTH = 1000;
		WINDOW_HEIGHT = primaryScreenBounds.getHeight() - primaryScreenBounds.getMinY() - 100;
		if (WINDOW_HEIGHT > 800)
			WINDOW_HEIGHT = 800;

		theStage.setTitle("Personal Knowledge Management Tool"); // Label the stage's window
		Pane root = new Pane();// Create a pane within the window.
		Pane theRoot = new Pane(); // Create a pane for the addresses window.
		Pane theRoot0 = new Pane();// Create a pane for the dictionary window.
		TabPane tabPane = new TabPane();

		BorderPane borderPane = new BorderPane();
		theGUI0 = new UserInterface(theRoot0); // GUI0 is made for the Dictionary Window.
		theGUI = new UserInterfaceAdd(theRoot);// GUI is made for the Addresses window.
	    theGUI.appendAddress( internadd); // To show the Intern Address (My Address)
		theGUI.appendAddress( clientadd ); //To show the Client address
		 
																							

		Tab Tab1 = new Tab();
		Tab1.setText("Contacts  ");  
		Tab1.setContent(theRoot);
		Tab Tab2 = new Tab();
		Tab2.setText("Dictionary"); 
		Tab2.setContent(theRoot0);
		Tab Tab3 = new Tab();
		Tab3.setText("Spare");   
		tabPane.getTabs().addAll(	Tab1, 	Tab2, 	Tab3);
		borderPane.setCenter(tabPane);
		root.getChildren().add(borderPane);

		Scene theScene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT); 
		// Creation of the scene and setting of the attributes.

		borderPane.prefHeightProperty().bind(theScene.heightProperty());
		borderPane.prefWidthProperty().bind(theScene.widthProperty());
		theStage.setScene(theScene);
		theStage.show();
	}

	

	/*******************************************************************************************************/

	/*******************************************************************************************************
	 * This is the method that launches the JavaFX application
	 * 
	 * @param args are the program parameters and they are not used by this program.
	 * 
	 */
	public static void main(String[] args) { // This method may not be required
		launch(args); // for all JavaFX applications using
	} // other IDEs.
}