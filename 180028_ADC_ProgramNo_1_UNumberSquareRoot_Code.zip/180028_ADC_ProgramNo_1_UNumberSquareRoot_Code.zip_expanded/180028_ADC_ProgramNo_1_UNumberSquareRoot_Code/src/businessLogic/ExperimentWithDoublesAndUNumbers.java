package businessLogic;

/**********
/* <p> Title: Experiment with numbers </p>
* 
* <p> Description: A sample program to experiment with the UNumber library  in order to produce
* code that computes expressions with value with far more than a double values number of 
* significant digits.</p>
* 
* <p> Copyright: Copyright © 2018 </p>
* 
* @author Lynn Robert Carter
* @author Sajib Biswas
* 
* @version 1.00	The initial version
* @version 1.1 Implemention of Square Root by Newton Rapson Method
* 
*/

import uNumberLibrary.UNumberWithSqrt;

public class ExperimentWithDoublesAndUNumbers
{
	public static void main (String [] args) {	
		
		// Example 1
		
		UNumberWithSqrt a = new UNumberWithSqrt("132545",2,true,25);
		UNumberWithSqrt b = new UNumberWithSqrt("2",1,true,25);
		UNumberWithSqrt c = new UNumberWithSqrt("3165",1,true,25);
		
		// Compute x = ((a - b) * (a + b)) / c;  using double values
		
		double result = (13.2545 - 2) * (13.2545 + 2) / 3.165;
		
		// Display a, b, and c
		
		System.out.println("Using doubles");
		System.out.println("a = 13.2545");
		System.out.println("b = 2");
		System.out.println("c = 3.165");
		System.out.println("result = (13.2545 - 2) * (13.2545 + 2) / 3.165 = " + result);
		
				
		// Compute x = ((a - b) * (a + b)) / c; using UNumber values
		
		System.out.println("\nUsing UNumber values");
		System.out.println("a = " + a.toDecimalString());
		System.out.println("b = " + b.toDecimalString());
		System.out.println("c = " + c.toDecimalString());

		UNumberWithSqrt x = new UNumberWithSqrt(a);
		UNumberWithSqrt temp = new UNumberWithSqrt(a);
		
		temp.add(b);
		System.out.println("a + b = " + temp.toDecimalString());
		x.sub(b);
		System.out.println("a - b = " + x.toDecimalString());
		x.mpy(temp);
		System.out.println("(a - b) * (a + b) = " + x.toDecimalString());
		x.div(c);
		System.out.println("x = (a - b) * (a + b) / c = " + x.toDecimalString());
        x.sqrt();
        System.out.println();
	};
}
