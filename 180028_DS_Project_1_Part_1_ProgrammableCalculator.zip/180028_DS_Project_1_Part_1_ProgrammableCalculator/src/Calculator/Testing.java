package Calculator;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * <p> Title: Testing Class. </p>
 * 
 * <p> Description: The code will check all the arithmetic operation of UI-1 by using JUnit.</p>
 * 
 * @author Sajib Biswas
 * @version 1.0 Test all the arithmetic operation
 *
 */



public class Testing {

	@Test   //Test the addition operation
	public void testADD() {
		double want=10;
		CalculatorValue t=new CalculatorValue(5,0);
		t.add(new CalculatorValue(5,0));
		double main=Double.parseDouble(t.toString());
		assertTrue(main==want);
		
	}
	@Test  //Test the subtraction operation
	public void testSUB() {
		double want=10;
		CalculatorValue t=new CalculatorValue(15,0);
		t.sub(new CalculatorValue(5,0));
		double main=Double.parseDouble(t.toString());
		assertTrue(main==want);
		
	}
	@Test   //Test the multiplication operation
	public void testMPY() {  
		double want=75;
		CalculatorValue t=new CalculatorValue(15,1);
		t.mpy(new CalculatorValue(5,1));
		double main=Double.parseDouble(t.toString());
		assertTrue(main==want);
		
	}
	@Test   //Test the division operation
	public void testDIV() {  
		double want=3;
		CalculatorValue t=new CalculatorValue(15,1);
		t.div(new CalculatorValue(5,1));
		double main=Double.parseDouble(t.toString());
		assertTrue(main==want);
		
	}
	
	
	@Test   //Test the square root operation
	public void testSQRT() {
		double want=4;
		CalculatorValue t=new CalculatorValue(16,0);
		t.sqrt(t);
		double main=Double.parseDouble(t.toString());
		assertTrue(main==want);
		
	}
	
	

}
