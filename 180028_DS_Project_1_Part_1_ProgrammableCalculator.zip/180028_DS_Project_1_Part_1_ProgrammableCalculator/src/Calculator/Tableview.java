package Calculator;

import javafx.application.Application;

import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.TableColumn;

import javafx.scene.control.TableView;

import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import neww.Entries;

import java.io.File;

import java.io.FileReader;
import java.util.ArrayList;

/**
 * <p> Title: Tableview Class. </p>
 * 
 * <p> Description: The code will create a new window that show the defined data
 * and it allows user to search, create, delete,update data..</p>
 * 
 * @author Sajib Biswas
 * @version 1.0 TableView to view the stored data and perform CRUD operation
 *
 */


public class Tableview extends Application {

    private File file;

    @SuppressWarnings("rawtypes")
	private TableColumn Measure, Error, Units, Name, Type;

    @SuppressWarnings("rawtypes")
	private final TableView table = new TableView<>();

    @SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
    public void start(Stage stage) {


        Scene scene = new Scene(new Group());
        stage.setWidth(480);
        stage.setHeight(550);
        final HBox hb = new HBox();

        table.setEditable(true);

        Name = new TableColumn<>("Name");
        Name.setMinWidth(100);

        Type = new TableColumn<>("Type");
        Type.setMinWidth(100);


//        table.getColumns().addAll(Name, Value, Type);
        Measure = new TableColumn("Measure Value");
        Error = new TableColumn("Error Term");
        Units = new TableColumn("Units");
     

        table.getColumns().addAll(Name, Measure, Error, Units, Type);

        final Button addButton = new Button("Add");
        final Button searchButton = new Button("Search");
        final Button updateButton = new Button("Update");
        final Button deleteButton = new Button("Delete");
        final Button exit = new Button("Exit");
        hb.getChildren().addAll( searchButton,addButton,updateButton,deleteButton,exit);
        hb.setSpacing(3);
        
        addButton.setOnAction((event) -> {
			  try {
				(new CVDefinition()).start(new Stage());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			  });
        exit.setOnAction((event)->{
        	System.exit(0);
        });
        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(table,hb);
        
        
        
        
        
        ((Group) scene.getRoot()).getChildren().addAll(vbox);
        stage.setTitle("Table View");
        stage.setScene(scene);
        stage.show();

        file = new File(System.getProperty("user.dir") + "//repo.txt");

        addData();
    }

    @SuppressWarnings("unchecked")
	private void addData() {
        Name.setCellValueFactory(new PropertyValueFactory<>("name"));
        @SuppressWarnings("unused")
		String name = "ss";

        Name.setCellValueFactory(new PropertyValueFactory<>("name"));
        Measure.setCellValueFactory(new PropertyValueFactory<>("measuredValue"));
        Error.setCellValueFactory(new PropertyValueFactory<>("errorValue"));
        Units.setCellValueFactory(new PropertyValueFactory<>("unit"));
        Type.setCellValueFactory(new PropertyValueFactory<>("type"));

        ArrayList<Entries> entries = readRepo();
        for (int i = 0; i <= entries.size()-1; i++) {
            table.getItems().add(entries.get(i));
        }
        table.getItems().add(new Entries("Con","20.5","0.05","m","Constant"));
        table.getItems().add(new Entries("Var","2.1","0.01","km","Variable"));

    }

    public ArrayList<Entries> readRepo() {
        ArrayList<Entries> toReturn = new ArrayList<>();
        try {
            file = new File(System.getProperty("user.dir") + "//repo.txt");
            @SuppressWarnings("resource")
			FileReader reader = new FileReader(file);
            int i;
            String[] arr = new String[5];
            arr[0] = ""; arr[1] = ""; arr[2] = ""; arr[3] = ""; arr[4] = "";
            int arrIndx = 0;
            while ((i = reader.read()) != -1) {
                if ((char)i == ',') {
                    arrIndx++;
                    continue;
                }
                if ((char)i == '\n') {
                    arrIndx = 0;
                    toReturn.add(new Entries(arr[0], arr[1], arr[2], arr[3], arr[4]));
                    arr = new String[5];
                    arr[0] = ""; arr[1] = ""; arr[2] = ""; arr[3] = ""; arr[4] = "";
                    continue;
                }
                arr[arrIndx] += "" + (char)i;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return toReturn;
    }
}
